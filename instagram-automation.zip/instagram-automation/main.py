from selenium import webdriver
from time import sleep

class InstaBot:
    def __init__(self, username, password, message, user):
        self.username = username
        self.user = user
        self.message = message
        #Opening and signing into Instagram
        self.driver = webdriver.Chrome()
        self.driver.get("https://instagram.com")
        sleep(2)
        self.driver.find_element_by_xpath("//input[@name=\"username\"]")\
            .send_keys(username)
        self.driver.find_element_by_xpath("//input[@name=\"password\"]")\
            .send_keys(password)
        self.driver.find_element_by_xpath('//button[@type="submit"]')\
            .click()
        sleep(4)

        #"Not Now" to Pop-up
        self.driver.find_element_by_xpath("//button[contains(text(), 'Not Now')]")\
            .click()
        self.driver.find_element_by_xpath("//button[contains(text(), 'Not Now')]")\
            .click()
        sleep(2)
        #Select DM Button
        self.driver.find_element_by_xpath('//a[@href="/direct/inbox/"]')\
            .click()
        sleep(2)
        
        #Select New DM
        self.driver.find_element_by_xpath('//*[@id="react-root"]/section/div/div[2]/div/div/div[1]/div[1]/div/div[3]/button')\
            .click()

        self.driver.find_element_by_xpath('/html/body/div[4]/div/div/div[2]/div[2]/div[2]/div/div[3]/button').click()
        sleep(2)

        self.driver.find_element_by_xpath('/html/body/div[4]/div/div/div[1]/div/div[2]/div/button').click()
        sleep(2)

        self.driver.find_element_by_css_selector('#react-root > section > div > div.Igw0E.IwRSH.eGOV_._4EzTm > div > div > div.DPiy6.Igw0E.IwRSH.eGOV_.vwCYk > div.uueGX > div > div.Igw0E.IwRSH.eGOV_._4EzTm > div > div > div.Igw0E.IwRSH.eGOV_.vwCYk.ItkAi > textarea').send_keys(self.message)
        sleep(1)
        
        self.driver.find_element_by_xpath('//*[@id="react-root"]/section/div/div[2]/div/div/div[2]/div[2]/div/div[2]/div/div/div[3]/button').click()
        sleep(20)

my_bot = InstaBot('insta_bot.py', 'inst@uto', "Hello, World!", 'dulanwaduge')
#my_bot.get_unfollowers()
